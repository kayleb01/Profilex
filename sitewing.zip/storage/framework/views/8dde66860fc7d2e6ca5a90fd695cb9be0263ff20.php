<div class="min-h-screen flex flex-col sm:justify-center items-center pt-6 sm:pt-0 bg-gray-100">
    <div class="lg:w-2/5 w-full lg:h-2/5 rounded-lg shadow-lg items-center flex flex-col" style="background-color: #03A89E; !important">
        <div>
            <?php echo e($logo); ?>

        </div>

        <div class="w-full sm:max-w-md mt-6 px-6 py-4overflow-hidden sm:rounded-lg">
            <?php echo e($slot); ?>

        </div>
    </div>

</div>
<?php /**PATH /var/www/html/site-wings/resources/views/components/auth-card.blade.php ENDPATH**/ ?>