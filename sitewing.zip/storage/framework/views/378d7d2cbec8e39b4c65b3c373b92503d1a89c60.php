<div class="">
    <?php if($message = Session::get('success')): ?>
        <div class="bg-green-500 p-4 m-2 text-white rounded-sm border border-white">
            <?php echo e($message); ?>

        </div>
    <?php endif; ?>


    <?php if($message = Session::get('error')): ?>
        <div class="bg-red-500 text-white p-4 rounded-sm m-2">
            <?php echo e($message); ?>

        </div>
    <?php endif; ?>


    <?php if($message = Session::get('warning')): ?>
        <div class="alert alert-warning alert-block">
            <strong><?php echo e($message); ?></strong>
        </div>
    <?php endif; ?>


    <?php if($message = Session::get('info')): ?>
        <div class="alert alert-info alert-block">
            <strong><?php echo e($message); ?></strong>
        </div>
    <?php endif; ?>


    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        Please check the form below for errors
    </div>
    <?php endif; ?>
    <?php if($errors->any()): ?>
    <div class="bg-red-500 text-white p-4 m-2 rounded-sm">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
</div>
<?php /**PATH /var/www/html/site-wings/resources/views/partials/error-success.blade.php ENDPATH**/ ?>